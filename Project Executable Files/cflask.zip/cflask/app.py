import numpy as np
import pickle
from flask import Flask, request, render_template

app = Flask(__name__)
model = pickle.load(open("model.pkl", "rb"))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/prediction', methods=['GET', 'POST'])
def prediction():
    if request.method == 'POST':
        low = float(request.form["low"])
        high = float(request.form["high"])
        volume = float(request.form["volume"])
        open = float(request.form["open"])
        year = int(request.form["year"])
        month = int(request.form["month"])
        day = int(request.form["day"])
        company = int(request.form["company"])

        prediction = model.predict([[open, high, low, volume, year, month, day, company]])
        result_text = f"Forecasted closing price on {day}/{month}/{year} is ${prediction[0]:.2f}"
        return render_template('result.html', result_text=result_text)
    return render_template('prediction.html')


@app.route('/result', methods=['POST'])
def result():
    low = float(request.form["low"])
    high = float(request.form["high"])
    volume = float(request.form["volume"])
    open = float(request.form["open"])
    year = int(request.form["year"])
    month = int(request.form["month"])
    day = int(request.form["day"])
    company = int(request.form["company"])

    prediction = model.predict([[open, high, low, volume, year, month, day, company]])
    result_text = f"Forecasted closing price on {day}/{month}/{year} is ${prediction[0]:.2f}"
    return render_template('result.html', result_text=result_text)

if __name__ == '__main__':
    app.run(debug=True)
